package com.yang.apm.springplugin.config;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.yang.apm.springplugin.base.item.DetectionResItem;
import com.yang.apm.springplugin.pojo.result.SvcRes;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Configuration
public class CacheConfig {


    @Bean
    public Cache<String, List<SvcRes>> svcResCache(){
        return CacheBuilder.newBuilder()
                .maximumSize(10_000)
                .expireAfterWrite(610, TimeUnit.SECONDS)
                .recordStats()
                .build();
    }

//    public Cache<HashSet<DetectionResItem>> resultItem(){
//        return CacheBuilder.newBuilder()
//                .maximumSize(10_000)
//                .expireAfterWrite(610, TimeUnit.SECONDS)
//                .recordStats()
//                .build();
//    }


}
