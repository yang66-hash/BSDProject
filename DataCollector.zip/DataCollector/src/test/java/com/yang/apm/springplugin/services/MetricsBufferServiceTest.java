package com.yang.apm.springplugin.services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest(classes = com.yang.apm.springplugin.DataCollectApplication.class)
class MetricsBufferServiceTest {


    @Test
    public void test() {

    }
}