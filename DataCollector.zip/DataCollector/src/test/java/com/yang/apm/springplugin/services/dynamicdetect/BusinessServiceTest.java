package com.yang.apm.springplugin.services.dynamicdetect;

import com.yang.apm.springplugin.pojo.result.business.BusinessMetricsRes;
import com.yang.apm.springplugin.services.metricscollector.BusinessMetricsService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class BusinessServiceTest {

    @Autowired
    private BusinessMetricsService businessService;

    @Test
    public void testBusinessService() {

        List<BusinessMetricsRes> businessMetrics = businessService.getBusinessMetrics("2025-09-12 07:49:46", 300);
        System.out.println(businessMetrics);
    }

}